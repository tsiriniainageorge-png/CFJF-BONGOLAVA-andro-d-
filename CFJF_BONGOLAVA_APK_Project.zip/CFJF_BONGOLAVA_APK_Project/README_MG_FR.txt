# CFJF BONGOLAVA — Android APK project

Ity dia projet Android (WebView) mitondra ny logiciel gestion offline CFJF BONGOLAVA.

## Fanamboarana APK amin'ny Android Studio
1. Ampidiro amin'ny ordinateur ny Android Studio.
2. Sokafy Android Studio > Open, dia fidio ny dossier `CFJF_BONGOLAVA_APK_Project`.
3. Avelao hisintona ny Gradle sy Android SDK ilaina.
4. Mandehana amin'ny **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Rehefa vita dia tsindrio **Locate**. Matetika ny APK dia ao amin'ny `app/build/outputs/apk/debug/app-debug.apk`.
6. Alefaso amin'ny téléphone Android ilay APK, dia sokafy. Raha ilaina, avelao ny installation avy amin'ny source nahazoanao azy.

## Zava-dehibe
- Natao ho an'ny fampiasana offline ny app; ny angona dia tehirizina ao amin'ny stockage local an'ilay application.
- Ampiasao matetika ny **Sauvegarde** ao amin'ny app.
- Tsy mbola APK voa-compilé ity ZIP ity; projet source vonona hosokafana sy hamboarina amin'ny Android Studio izy.
- Mila Android SDK / Gradle misintona amin'ny Internet amin'ny fanamboarana voalohany.
